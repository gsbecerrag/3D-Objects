{
  'name':'Tutorial theme',
  'description': 'A description for your theme.',
  'version':'1.0',
  'author':'Galo Becerra',

  'data': [
  ],
  'category': 'Theme/Creative',
  'depends': ['website'],
}